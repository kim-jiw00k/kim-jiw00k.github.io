package org.javaro.lecture;
import org.javaro.lecture.Book;import org.javaro.lecture.BookStore;import org.javaro.lecture.Student;
public class MyStore {
	public static void main(String[]args) {
		//create a new MyLibrary
		BookStore myStore=new BookStore("지산 도서관");
		Book book1 = new Book("9788901161236","홍길동전"); 
		Book book2 = new Book("9788901162135","심청전");
		Book book3 = new Book("1234567891011","춘향전");
		Book book4 = new Book("1234567890101","전쟁과평화");
		Book book5 = new Book("9876543211010","논어");
		book1.setAuthor("허균");book2.setAuthor("미상");
		book3.setAuthor("미상");book4.setAuthor("레프 톨스토이");book5.setAuthor("미상");
		Student stud1 = new Student("202X1234");
		Student stud2=new Student("202X5678");
		Student stud3=new Student("202X0123");
		Student stud4=new Student("202X2345");
		stud1.setName("이몽룡"); stud2.setName("변학도");
		stud3.setName("성춘향"); stud4.setName("홍길동");
		myStore.addBook(book1); myStore.addBook(book2);
		myStore.addBook(book3);myStore.addBook(book4);myStore.addBook(book5);
		myStore.addStudent(stud1); myStore.addStudent(stud2);
		myStore.addStudent(stud3);myStore.addStudent(stud4);
		System.out.println("도서관리 시스템 생성");
		myStore.printStatus();
		System.out.println("book3 춘향전을 stud4 홍길동에게 대출");
		myStore.checkOut(book3, stud4);
		System.out.println("book2 심청전을 stud4 홍길동에게 대출");
		myStore.checkOut(book2, stud4);
		System.out.println("book2 심청전 반납");
		myStore.checkIn(book2);
		System.out.println("book2 심청전을 stud2 변학도에게 대출");
		myStore.checkOut(book2, stud2);
		System.out.println("book4 전쟁과평화를 stud3 성춘향에게 대출");
		myStore.checkOut(book4, stud3);
		System.out.println("book5 논어를 stud2 변학도에게 대출");
		myStore.checkOut(book5, stud2);
		System.out.println("book4 전쟁과평화 반납");
		myStore.checkIn(book4);
		myStore.printStatus();
	}
}
